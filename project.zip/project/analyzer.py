import datetime
from collections import defaultdict

class TrafficAnalyzer:
    def __init__(self):
        # Dictionary to track which ports each source IP has attempted to connect to
        self.ip_ports_scanned = defaultdict(set)
        
        # Threshold: if an IP hits this many unique ports, we flag it as a port scan
        self.PORT_SCAN_THRESHOLD = 15
        
        # Keep a history of all alerts generated (now as structured dictionaries)
        self.alerts = []
        self.alert_id_counter = 1

    def add_alert(self, severity, title, description, src_ip=None):
        """Helper to create a structured alert dictionary and append it."""
        alert = {
            "id": self.alert_id_counter,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "severity": severity,  # 'critical', 'warning', 'info'
            "title": title,
            "description": description,
            "src_ip": src_ip or "Unknown"
        }
        # Prepend so newest is always at the beginning (index 0)
        self.alerts.insert(0, alert)
        self.alert_id_counter += 1
        return alert

    def analyze_packet(self, packet_info):
        """
        Takes summarized packet information and applies security rules.
        Returns a structured alert dict if a rule is triggered, else None.
        """
        if not packet_info:
            return None

        src_ip = packet_info.get("src_ip")
        dst_port = packet_info.get("dst_port")
        flags = packet_info.get("flags", "")
        payload_len = packet_info.get("payload_len", 0)
        protocol = packet_info.get("protocol")

        # Rule 1: Detect Port Scans
        if protocol == "TCP" and "S" in flags and "A" not in flags:
            if src_ip and dst_port:
                self.ip_ports_scanned[src_ip].add(dst_port)
                
                if len(self.ip_ports_scanned[src_ip]) >= self.PORT_SCAN_THRESHOLD:
                    # Reset the count for this IP to prevent alert spam
                    self.ip_ports_scanned[src_ip].clear()
                    
                    return self.add_alert(
                        severity="critical",
                        title="Port Scan Detected",
                        description=f"IP {src_ip} has scanned {self.PORT_SCAN_THRESHOLD} unique ports.",
                        src_ip=src_ip
                    )

        # Rule 2: Detect Unusually Large UDP Packets
        if protocol == "UDP" and payload_len > 1000:
            return self.add_alert(
                severity="warning",
                title="Large UDP Payload",
                description=f"Payload of {payload_len} bytes sent to port {dst_port}.",
                src_ip=src_ip
            )
            
        return None
