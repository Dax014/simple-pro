import socket
import time

def trigger_large_udp():
    print("[*] Sending a large UDP packet to 8.8.8.8 (Google DNS)...")
    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # 1200 bytes of 'X's. Our threshold is > 1000 bytes.
    payload = b'X' * 1200 
    sock.sendto(payload, ("8.8.8.8", 53))
    print("[+] Large UDP packet sent!")

def trigger_port_scan():
    print("\n[*] Simulating a port scan by attempting to connect to 20 ports on 8.8.8.8...")
    # Our threshold is 15 unique ports
    for port in range(8000, 8025):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.1) # Super short timeout so we don't hang
        try:
            # We don't care if it connects, the attempt itself sends the TCP SYN packet!
            sock.connect(("8.8.8.8", port))
        except:
            pass
        finally:
            sock.close()
    print("[+] Port scan simulation complete!")

if __name__ == "__main__":
    print("=== Alert Trigger Script ===")
    trigger_large_udp()
    time.sleep(1)
    trigger_port_scan()
    print("============================")
    print("Check your Live Capture terminal to see if the alerts popped up!")
