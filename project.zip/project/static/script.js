document.addEventListener('DOMContentLoaded', () => {
    const alertsContainer = document.getElementById('alerts-container');
    const totalAlertsEl = document.getElementById('total-alerts');
    const criticalAlertsEl = document.getElementById('critical-alerts');
    
    let renderedAlertIds = new Set();
    let totalCount = 0;
    let criticalCount = 0;

    function createAlertCard(alert) {
        const card = document.createElement('div');
        card.className = `alert-card severity-${alert.severity}`;
        
        card.innerHTML = `
            <div class="alert-header">
                <span class="alert-title">${alert.title}</span>
                <span class="alert-time">${alert.timestamp}</span>
            </div>
            <div class="alert-desc">${alert.description}</div>
            <div class="alert-ip">SRC IP: ${alert.src_ip}</div>
        `;
        return card;
    }

    function fetchAlerts() {
        fetch('/api/alerts')
            .then(response => response.json())
            .then(alerts => {
                // If this is the very first alert, clear the "No alerts" message
                if (alerts.length > 0 && renderedAlertIds.size === 0) {
                    alertsContainer.innerHTML = '';
                }

                // Process alerts (they come from the backend with newest first)
                // We want to add new ones to the top.
                // We'll iterate backwards so the absolute newest is added last (at the top)
                let newAlertsFound = false;
                
                for (let i = alerts.length - 1; i >= 0; i--) {
                    const alert = alerts[i];
                    if (!renderedAlertIds.has(alert.id)) {
                        newAlertsFound = true;
                        
                        // Add to DOM at the top
                        const card = createAlertCard(alert);
                        alertsContainer.prepend(card);
                        
                        // Mark as rendered
                        renderedAlertIds.add(alert.id);
                        
                        // Update stats
                        totalCount++;
                        if (alert.severity === 'critical') {
                            criticalCount++;
                        }
                    }
                }

                if (newAlertsFound) {
                    totalAlertsEl.textContent = totalCount;
                    criticalAlertsEl.textContent = criticalCount;
                }
            })
            .catch(error => console.error('Error fetching alerts:', error));
    }

    function fetchActiveScans() {
        fetch('/api/scans')
            .then(response => response.json())
            .then(scans => {
                const activeScansList = document.getElementById('active-scans-list');
                if (!activeScansList) return;
                
                const ips = Object.keys(scans);
                if (ips.length === 0) {
                    activeScansList.innerHTML = '<span style="color: var(--text-muted);">None in progress...</span>';
                    return;
                }
                
                let html = '';
                ips.forEach(ip => {
                    html += `<div><span style="color: var(--accent-blue);">${ip}</span>: ${scans[ip]}/15 ports</div>`;
                });
                activeScansList.innerHTML = html;
            })
            .catch(error => console.error('Error fetching scans:', error));
    }

    // Fetch immediately on load
    fetchAlerts();
    fetchActiveScans();
    
    // Poll every 1 second (1000ms) for real-time updates
    setInterval(() => {
        fetchAlerts();
        fetchActiveScans();
    }, 1000);
});
