from flask import Flask, render_template, jsonify
import threading
from sniffer import PacketSniffer
from analyzer import TrafficAnalyzer

app = Flask(__name__)

# Initialize our core components globally so both the web server and sniffer can access them
analyzer = TrafficAnalyzer()
sniffer = PacketSniffer(analyzer)

@app.route("/")
def index():
    """Serves the main dashboard HTML page."""
    return render_template("index.html")

@app.route("/api/alerts")
def get_alerts():
    """API endpoint for the frontend to fetch the latest alerts."""
    return jsonify(analyzer.alerts)

@app.route("/api/scans")
def get_active_scans():
    """API endpoint for real-time port scan tracking."""
    # Convert the sets to just length counts for the frontend
    scans = {ip: len(ports) for ip, ports in analyzer.ip_ports_scanned.items() if len(ports) > 0}
    return jsonify(scans)

def start_sniffer_background():
    """Runs the sniffer. This will be executed in a separate background thread."""
    print("[*] Background Sniffer Thread Starting...")
    try:
        # Pass None for default interface, count=0 for infinite
        sniffer.start_sniffing(interface=None, count=0)
    except Exception as e:
        print(f"[!] Sniffer encountered an error: {e}")

if __name__ == "__main__":
    # 1. Start the packet sniffer in a daemon thread so it runs in the background
    # and automatically dies when the main Flask app closes.
    sniff_thread = threading.Thread(target=start_sniffer_background, daemon=True)
    sniff_thread.start()
    
    # 2. Start the Flask web server
    print("[*] Starting Web Dashboard on http://127.0.0.1:5000")
    # debug=False is important here because debug=True creates a second watcher process
    # which would start two sniffers and cause issues.
    app.run(host="127.0.0.1", port=5000, debug=False)
