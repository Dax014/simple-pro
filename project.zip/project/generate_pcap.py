from scapy.all import IP, TCP, UDP, Raw, wrpcap
import random

def generate_test_traffic():
    packets = []
    
    # 1. Normal HTTP Traffic
    print("Generating normal traffic...")
    for i in range(5):
        # We simulate a GET request. This will actually trigger our cleartext HTTP rule in analyzer.py
        pkt = IP(src="192.168.1.100", dst="192.168.1.1") / TCP(sport=random.randint(1024, 65535), dport=80, flags="PA") / Raw(load="GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
        packets.append(pkt)

    # 2. Port Scan (Simulating an attack from 10.0.0.50)
    # We send SYN ('S') packets to multiple ports
    print("Generating port scan traffic...")
    scan_ip = "10.0.0.50"
    for port in range(20, 40): # Scans 20 ports (threshold is 15)
        pkt = IP(src=scan_ip, dst="192.168.1.5") / TCP(sport=random.randint(1024, 65535), dport=port, flags="S")
        packets.append(pkt)

    # 3. Large UDP Packet (Simulating a potential DDoS amplification or data leak)
    print("Generating large UDP packet...")
    large_payload = b"A" * 1200 # 1200 bytes of data (threshold is 1000)
    pkt = IP(src="10.0.0.100", dst="192.168.1.5") / UDP(sport=53, dport=12345) / Raw(load=large_payload)
    packets.append(pkt)
    
    print("Writing to sample.pcap...")
    wrpcap("sample.pcap", packets)
    print("sample.pcap generated successfully!")

if __name__ == "__main__":
    generate_test_traffic()
