from scapy.all import sniff, IP, TCP, UDP, Raw

def extract_packet_info(packet):
    """
    Extracts relevant fields from a Scapy packet into a simple dictionary.
    This normalizes the data for our analyzer.
    """
    # We only care about IP packets for this basic analyzer
    if not packet.haslayer(IP):
        return None
        
    info = {
        "src_ip": packet[IP].src,
        "dst_ip": packet[IP].dst,
        "protocol": None,
        "src_port": None,
        "dst_port": None,
        "flags": "",
        "payload_len": 0
    }

    # Extract TCP specific fields
    if packet.haslayer(TCP):
        info["protocol"] = "TCP"
        info["src_port"] = packet[TCP].sport
        info["dst_port"] = packet[TCP].dport
        info["flags"] = packet[TCP].flags
        
        # Get payload size if it exists
        if packet.haslayer(Raw):
            info["payload_len"] = len(packet[Raw].load)
            
    # Extract UDP specific fields
    elif packet.haslayer(UDP):
        info["protocol"] = "UDP"
        info["src_port"] = packet[UDP].sport
        info["dst_port"] = packet[UDP].dport
        
        if packet.haslayer(Raw):
            info["payload_len"] = len(packet[Raw].load)
    else:
        info["protocol"] = "OTHER"

    return info

class PacketSniffer:
    def __init__(self, analyzer):
        self.analyzer = analyzer
        self.packet_count = 0

    def packet_callback(self, packet):
        """
        This function is called by Scapy for every packet captured.
        """
        self.packet_count += 1
        info = extract_packet_info(packet)
        
        if info:
            # Pass the normalized packet info to our analyzer
            alert = self.analyzer.analyze_packet(info)
            if alert:
                print(alert)
                
    def start_sniffing(self, interface=None, count=0, pcap_file=None):
        """
        Starts the packet capture process.
        Can either read from a file (offline) or listen on a network interface (live).
        """
        if pcap_file:
            print(f"[*] Analyzing offline PCAP file: {pcap_file}")
            # offline mode reads from a file instead of a live network card
            sniff(offline=pcap_file, prn=self.packet_callback, store=False)
        else:
            print(f"[*] Starting live packet capture...")
            print(f"[*] Interface: {interface if interface else 'default (all)'}")
            print(f"[*] Press Ctrl+C to stop.")
            try:
                # store=False prevents Scapy from keeping all packets in memory (prevents RAM exhaustion)
                sniff(iface=interface, prn=self.packet_callback, count=count, store=False)
            except PermissionError:
                print("\n[!] ERROR: You need Administrative privileges to capture live traffic on Windows.")
                print("[!] Please run the command prompt/terminal as Administrator.")
            except Exception as e:
                print(f"\n[!] An error occurred during live capture: {e}")
                print("[!] Ensure Npcap is installed on your Windows machine.")
            
        print(f"\n[*] Analysis complete. Total packets processed: {self.packet_count}")
