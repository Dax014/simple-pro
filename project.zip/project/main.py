import argparse
import sys
import csv
import re
from sniffer import PacketSniffer
from analyzer import TrafficAnalyzer
from colorama import Fore, Style, init

init(autoreset=True)

def parse_arguments():
    """Parse command line arguments for the tool."""
    parser = argparse.ArgumentParser(
        description="Python Network Traffic Analyzer (Mini-Snort/Wireshark)",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-i", "--interface", nargs='?', const='default', 
                       help="Start live capture on a specific interface. Use '-i' without a name for default interface.")
    group.add_argument("-r", "--read", help="Read packets from an offline .pcap file.")
    
    parser.add_argument("-c", "--count", type=int, default=0, help="Number of packets to capture (default is 0 for infinite)")
    parser.add_argument("-o", "--output", help="Save alerts to a CSV file (e.g., alerts.csv)")
    
    return parser.parse_args()

def clean_ansi_colors(text):
    """Removes terminal color codes from text so it can be cleanly saved to a file."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def main():
    print(f"""{Fore.CYAN}
    ================================================
           Network Traffic Analyzer v1.0
          (Packet Sniffer & Threat Detector)
    ================================================{Style.RESET_ALL}
    """)
    
    try:
        args = parse_arguments()
    except SystemExit:
        # User asked for help or provided invalid args
        return

    # 1. Initialize our Analysis Engine
    analyzer = TrafficAnalyzer()
    
    # 2. Initialize our Sniffer Engine and pass it the analyzer
    sniffer = PacketSniffer(analyzer)

    try:
        # 3. Start the capture/reading process
        # If args.interface is provided but empty, it defaults to 'default' due to const='default'
        interface = args.interface if args.interface != 'default' else None
        
        sniffer.start_sniffing(interface=interface, count=args.count, pcap_file=args.read)
        
    except KeyboardInterrupt:
        print("\n[*] Sniffing stopped by user (Ctrl+C).")

    # 4. Post-capture processing
    if analyzer.alerts:
        print(f"\n[*] Summary: Generated {Fore.RED}{len(analyzer.alerts)}{Style.RESET_ALL} total alerts during the session.")
        
        if args.output:
            print(f"[*] Saving alerts to {args.output}...")
            # Clean color codes before saving to CSV
            clean_alerts = [clean_ansi_colors(alert) for alert in analyzer.alerts]
            with open(args.output, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Alert'])
                for alert in clean_alerts:
                    writer.writerow([alert])
            print("[*] Save complete.")
    else:
        print(f"\n{Fore.GREEN}[*] No suspicious activity detected.{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
